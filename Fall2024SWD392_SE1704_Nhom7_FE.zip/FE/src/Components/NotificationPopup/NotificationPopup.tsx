import React from 'react'

const NotificationPopup = () => {
  return (
    <div>NotificationPopup</div>
  )
}

export default NotificationPopup