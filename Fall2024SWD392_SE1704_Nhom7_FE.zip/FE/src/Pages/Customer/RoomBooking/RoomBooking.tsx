import React from 'react'

const RoomBooking = () => {
  return (
    <div>RoomBooking</div>
  )
}

export default RoomBooking