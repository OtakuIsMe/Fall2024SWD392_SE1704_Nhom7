import React from 'react'

export const FavoriteList = () => {
  return (
    <div>FavoriteList</div>
  )
}
