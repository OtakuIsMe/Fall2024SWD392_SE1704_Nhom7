import React from 'react'

const ChangePassword = () => {
  return (
    <div>ChangePassword</div>
  )
}

export default ChangePassword